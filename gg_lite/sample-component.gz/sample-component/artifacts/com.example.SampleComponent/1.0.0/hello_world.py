import sys

message = "Hello, World!"

# Print the message to stdout, which Greengrass saves in a log file.
print(message)
